package ar.edu.fcyt.ingsoftII.patrones.observer;

import java.util.ArrayList;
import java.util.List;

public class Sujeto {

	private List<Observer> observadores = new ArrayList<Observer>();

	private int estado;

	public int getEstado() {
		return estado;
	}

	public void setEstado(int estado) {
		this.estado = estado;
		notificarObservadores();
	}

	public void agregarObservador(Observer observador) {
		observadores.add(observador);
	}

	public void notificarObservadores() {
		for (Observer observador : observadores) {
			observador.update();
		}
	}

}

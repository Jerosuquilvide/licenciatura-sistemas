package ar.edu.fcyt.ingsoftII.patrones.strategy;

public class Sumar implements Operacion {

	@Override
	public void realizarOperacion(int numero1, int numero2) {
		System.out.println(numero1 + " + " + numero2 + " = " + (numero1 + numero2));
	}

}

package ar.edu.fcyt.ingsoftII.patrones.facade;

public class Rectangulo implements Figura {

	@Override
	public void dibujar() {
		System.out.println("dibujando un rectangulo");

	}

}

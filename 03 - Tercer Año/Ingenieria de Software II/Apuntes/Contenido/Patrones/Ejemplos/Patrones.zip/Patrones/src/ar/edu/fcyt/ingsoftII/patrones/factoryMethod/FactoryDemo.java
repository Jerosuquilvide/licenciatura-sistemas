package ar.edu.fcyt.ingsoftII.patrones.factoryMethod;

import ar.edu.fcyt.ingsoftII.patrones.facade.Figura;

public class FactoryDemo {

	public static void main(String[] args) {
		
		FiguraFactory factory = new FiguraFactory();
		
		Figura figura = factory.fabricarFigura("TRIANGULO");

		figura.dibujar();

	}

}

package ar.edu.fcyt.ingsoftII.patrones.facade;

public class Circulo implements Figura {

	@Override
	public void dibujar() {
		System.out.println("dibujando un circulo");

	}

}

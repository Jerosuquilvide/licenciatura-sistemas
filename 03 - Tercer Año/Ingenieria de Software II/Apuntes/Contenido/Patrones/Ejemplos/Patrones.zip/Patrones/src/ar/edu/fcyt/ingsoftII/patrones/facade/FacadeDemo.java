package ar.edu.fcyt.ingsoftII.patrones.facade;

public class FacadeDemo {

	public static void main(String[] args) {
		
		FiguraFacade facade = new FiguraFacade();
		
		facade.dibujarCirculo();
		
		facade.dibujarCuadrado();
		
		facade.dibujarRectangulo();
	}
}

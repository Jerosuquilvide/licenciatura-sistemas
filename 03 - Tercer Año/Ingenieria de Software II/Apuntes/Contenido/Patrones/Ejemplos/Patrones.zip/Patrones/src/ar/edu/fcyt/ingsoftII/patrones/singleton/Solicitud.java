package ar.edu.fcyt.ingsoftII.patrones.singleton;

public class Solicitud {

	public static void main(String[] args) {

//		GestorDB miGestor = GestorDB.getInstance();
//
//		miGestor.realizarConsulta();
//
//		// ....
//		GestorDB miGestor2 = GestorDB.getInstance();
//
//		miGestor2.realizarConsulta();

		GestorDB db = GestorDB.getInstance();

		db.realizarConsulta();

		GestorDB db2 = GestorDB.getInstance();

		db2.realizarConsulta();

		GestorDB db3 = GestorDB.getInstance();

		db3.realizarConsulta();

	}

}

package ar.edu.fcyt.ingsoftII.patrones.composite;

public class ArchivoImagen extends Archivo {

	@Override
	void mostrarContenido() {
		System.out.println("Mostrando una imagen");
		
	}

}

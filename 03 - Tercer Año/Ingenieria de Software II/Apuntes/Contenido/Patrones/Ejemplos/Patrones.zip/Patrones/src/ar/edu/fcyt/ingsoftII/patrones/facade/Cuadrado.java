package ar.edu.fcyt.ingsoftII.patrones.facade;

public class Cuadrado implements Figura {

	@Override
	public void dibujar() {
		System.out.println("dibujando un cuadrado");

	}

}

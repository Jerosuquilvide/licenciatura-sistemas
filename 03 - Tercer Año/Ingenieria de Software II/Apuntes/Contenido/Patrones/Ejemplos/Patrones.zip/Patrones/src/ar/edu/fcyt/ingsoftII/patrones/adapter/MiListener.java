package ar.edu.fcyt.ingsoftII.patrones.adapter;

import java.awt.event.WindowEvent;

public class MiListener extends VentanaAdapter {

	@Override
	public void windowClosed(WindowEvent e) {
		System.out.println("Cerrando la ventana");

	}
}

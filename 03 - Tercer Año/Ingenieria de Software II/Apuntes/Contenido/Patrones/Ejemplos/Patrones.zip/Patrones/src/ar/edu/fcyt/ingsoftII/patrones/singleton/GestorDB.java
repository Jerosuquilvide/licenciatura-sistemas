package ar.edu.fcyt.ingsoftII.patrones.singleton;

public class GestorDB {

	private String usuario;

	private String password;

	private String url;

	private static GestorDB instancia;

	private GestorDB() {
		System.out.println("Conectandome a la base de datos");
	}

	public void realizarConsulta() {
		System.out.println("Ejecutando una consula");
	}

	public static GestorDB getInstance() {
		if (instancia == null) {
			instancia = new GestorDB();
		}

		return instancia;
	}

}

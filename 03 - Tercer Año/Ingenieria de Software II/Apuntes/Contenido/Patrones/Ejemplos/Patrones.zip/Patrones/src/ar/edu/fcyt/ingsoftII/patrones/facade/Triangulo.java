package ar.edu.fcyt.ingsoftII.patrones.facade;

public class Triangulo implements Figura {

	@Override
	public void dibujar() {
		System.out.println("Dibujando un triangulo");

	}

}

package ar.edu.fcyt.ingsoftII.patrones.adapter;

public interface MediaPlayer {
	
	void play(String audioType, String filename);

}

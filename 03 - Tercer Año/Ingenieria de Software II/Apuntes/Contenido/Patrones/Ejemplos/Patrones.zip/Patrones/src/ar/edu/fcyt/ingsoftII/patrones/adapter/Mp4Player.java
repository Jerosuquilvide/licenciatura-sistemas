package ar.edu.fcyt.ingsoftII.patrones.adapter;

public class Mp4Player implements AdvancedMediaPlayer {

	@Override
	public void playVlc(String fileName) {
		// TODO Auto-generated method stub

	}

	@Override
	public void playMp4(String fileName) {
		System.out.println("Reproduciendo MP4: " + fileName);

	}

}

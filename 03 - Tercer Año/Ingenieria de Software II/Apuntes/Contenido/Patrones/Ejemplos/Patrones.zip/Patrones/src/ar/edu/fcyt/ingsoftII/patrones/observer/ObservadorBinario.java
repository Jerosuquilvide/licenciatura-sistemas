package ar.edu.fcyt.ingsoftII.patrones.observer;

public class ObservadorBinario extends Observer {

	public ObservadorBinario(Sujeto sujeto) {
		this.sujeto = sujeto;
		sujeto.agregarObservador(this);
	}

	@Override
	public void update() {
		System.out.println("Conversion a binario: " + Integer.toBinaryString(this.sujeto.getEstado()));

	}

}

package ar.edu.fcyt.ingsoftII.patrones.factoryMethod;

import ar.edu.fcyt.ingsoftII.patrones.facade.Circulo;
import ar.edu.fcyt.ingsoftII.patrones.facade.Cuadrado;
import ar.edu.fcyt.ingsoftII.patrones.facade.Figura;
import ar.edu.fcyt.ingsoftII.patrones.facade.Rectangulo;
import ar.edu.fcyt.ingsoftII.patrones.facade.Triangulo;

public class FiguraFactory {

	public Figura fabricarFigura(String nombreFigura) {

		switch (nombreFigura) {
		case "CUADRADO": {
			return new Cuadrado();
		}

		case "RECTANGULO": {
			return new Rectangulo();
		}

		case "CIRCULO": {
			return new Circulo();
		}
		case "TRIANGULO": {
			return new Triangulo();
		}
		default: {
			return null;
		}
		}
	}

}

package ar.edu.fcyt.ingsoftII.patrones.facade;

public class Azul implements Color {

	@Override
	public void pintar() {
		System.out.println("Pintando de azul");

	}

}

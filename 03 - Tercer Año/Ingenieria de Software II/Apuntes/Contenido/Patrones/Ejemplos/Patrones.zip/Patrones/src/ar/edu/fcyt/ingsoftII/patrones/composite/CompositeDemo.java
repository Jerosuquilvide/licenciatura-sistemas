package ar.edu.fcyt.ingsoftII.patrones.composite;

public class CompositeDemo {

	public static void main(String[] args) {

		// Gerente de la empresa
		Empleado ceo = new Empleado("Jorge Lopez", "Direccion", 2500.0);

		// CEO ----> Jefe Marketing / Jefe de Produccion
		Empleado jefeMarketing = new Empleado("Laura Gomez", "Jefe de Marketing", 2000.0);

		Empleado jefeProduccion = new Empleado("Ramiro Cabrera", "Jefe de Produccion", 2000.0);

		ceo.agregarSubordinado(jefeProduccion);
		ceo.agregarSubordinado(jefeMarketing);

		// Jefe de Marketing ---> 3 empleados
		Empleado empleadoMarketing1 = new Empleado("Josefina Perez", "Marketing", 1000.0);

		Empleado empleadoMarketing2 = new Empleado("Delfina Casas", "Marketing", 1000.0);

		Empleado empleadoMarketing3 = new Empleado("Lautaro Gomez", "Marketing", 1000.0);

		jefeMarketing.agregarSubordinado(empleadoMarketing1);
		jefeMarketing.agregarSubordinado(empleadoMarketing2);
		jefeMarketing.agregarSubordinado(empleadoMarketing3);

//		empleadoMarketing1.mostrarInformacion();
		jefeMarketing.mostrarInformacion();

	}

}

package ar.edu.fcyt.ingsoftII.patrones.adapter;

public class AudioPlayer implements MediaPlayer {

	@Override
	public void play(String audioType, String filename) {
		// TODO Auto-generated method stub

	}
	
}

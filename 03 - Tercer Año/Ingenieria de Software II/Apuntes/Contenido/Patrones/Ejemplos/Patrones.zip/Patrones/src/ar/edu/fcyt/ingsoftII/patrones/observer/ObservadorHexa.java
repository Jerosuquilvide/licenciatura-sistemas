package ar.edu.fcyt.ingsoftII.patrones.observer;

public class ObservadorHexa extends Observer {
	public ObservadorHexa(Sujeto sujeto) {
		this.sujeto = sujeto;
		sujeto.agregarObservador(this);
	}

	@Override
	public void update() {
		System.out.println("Conversion a Hexadecimal: " + Integer.toHexString(this.sujeto.getEstado()));

	}

}

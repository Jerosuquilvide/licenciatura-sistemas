package ar.edu.fcyt.ingsoftII.patrones.facade;

public interface Figura {

	public void dibujar();
}

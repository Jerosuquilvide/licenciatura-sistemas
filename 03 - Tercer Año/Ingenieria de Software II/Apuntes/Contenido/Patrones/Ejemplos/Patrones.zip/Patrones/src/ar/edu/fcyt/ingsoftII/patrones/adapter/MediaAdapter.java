package ar.edu.fcyt.ingsoftII.patrones.adapter;

public class MediaAdapter implements MediaPlayer {

	AdvancedMediaPlayer advancedMusicPlayer;

	public MediaAdapter(String fileType) {
		if (fileType.equalsIgnoreCase("vlc")) {
			advancedMusicPlayer = new VlcPlayer();
		}

		if (fileType.equalsIgnoreCase("mp4")) {
			advancedMusicPlayer = new Mp4Player();
		}
	}

	@Override
	public void play(String audioType, String filename) {
		if (audioType.equalsIgnoreCase("vlc")) {
			advancedMusicPlayer.playVlc(filename);
		}

		if (audioType.equalsIgnoreCase("mp4")) {
			advancedMusicPlayer.playMp4(filename);
		}

	}

}

package ar.edu.fcyt.ingsoftII.patrones.observer;

public abstract class Observer {

	protected Sujeto sujeto;

	public abstract void update();
}

package ar.edu.fcyt.ingsoftII.patrones.strategy;

public interface Operacion {
	void realizarOperacion(int numero1, int numero2);
}

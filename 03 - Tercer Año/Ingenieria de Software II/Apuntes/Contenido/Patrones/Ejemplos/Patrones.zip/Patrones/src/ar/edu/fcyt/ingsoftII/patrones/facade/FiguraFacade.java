package ar.edu.fcyt.ingsoftII.patrones.facade;

public class FiguraFacade {

	private Circulo circulo;
	private Cuadrado cuadrado;
	private Rectangulo rectangulo;

	public FiguraFacade() {
		super();
		circulo = new Circulo();
		cuadrado = new Cuadrado();
		rectangulo = new Rectangulo();
	}

	public void dibujarCirculo() {
		circulo.dibujar();
	}

	public void dibujarCuadrado() {
		cuadrado.dibujar();
	}

	public void dibujarRectangulo() {
		rectangulo.dibujar();
	}

}

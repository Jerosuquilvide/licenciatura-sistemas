package ar.edu.fcyt.ingsoftII.patrones.strategy;

public class Contexto {

	private Operacion operacion;

	public Contexto(Operacion operacion) {
		super();
		this.operacion = operacion;
	}

	public void ejecutarOperacion(int numero1, int numero2) {
		operacion.realizarOperacion(numero1, numero2);
	}
}

package ar.edu.fcyt.ingsoftII.patrones.facade;

public class ColorFactory {

	public Color fabricarColor(String nombreColor) {

		switch (nombreColor) {

		case "ROJO": {
			return new Rojo();
		}

		case "AZUL": {
			return new Azul();
		}

		case "VERDE": {
			return new Verde();
		}

		default: {
			return null;
		}
		}
	}

}

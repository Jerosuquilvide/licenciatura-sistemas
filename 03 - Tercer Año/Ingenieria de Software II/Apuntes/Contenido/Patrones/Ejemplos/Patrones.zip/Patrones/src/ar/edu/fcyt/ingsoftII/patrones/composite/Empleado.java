package ar.edu.fcyt.ingsoftII.patrones.composite;

import java.util.ArrayList;
import java.util.List;

public class Empleado {

	private String nombre;

	private String oficina;

	private Double sueldo;

	private List<Empleado> subordinados;

	public Empleado(String nombre, String oficina, Double sueldo) {
		super();
		this.nombre = nombre;
		this.oficina = oficina;
		this.sueldo = sueldo;
		this.subordinados = new ArrayList<Empleado>();
	}

	public void agregarSubordinado(Empleado empleado) {
		this.subordinados.add(empleado);
	}

	public void eliminarSubordinado(Empleado empleado) {
		this.subordinados.remove(empleado);
	}

	public List<Empleado> obtenerSubordinados() {
		return this.subordinados;
	}

	public void mostrarInformacion() {
		System.out.println("Nombre:" + nombre);
		System.out.println("Oficina:" + oficina);
		System.out.println("Sueldo:" + sueldo);
		if (!subordinados.isEmpty()) {
			System.out.println("Empleados a cargo:");
			for (Empleado empleado : subordinados) {
				empleado.mostrarInformacion();
			}

		}
	}

}

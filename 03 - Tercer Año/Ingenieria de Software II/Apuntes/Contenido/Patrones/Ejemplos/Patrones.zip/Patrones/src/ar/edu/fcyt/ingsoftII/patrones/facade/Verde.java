package ar.edu.fcyt.ingsoftII.patrones.facade;

public class Verde implements Color {

	@Override
	public void pintar() {
		System.out.println("Pintando de verde");

	}

}

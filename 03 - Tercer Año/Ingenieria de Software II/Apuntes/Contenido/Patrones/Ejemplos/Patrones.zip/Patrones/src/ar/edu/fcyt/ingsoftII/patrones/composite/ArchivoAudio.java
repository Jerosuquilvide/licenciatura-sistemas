package ar.edu.fcyt.ingsoftII.patrones.composite;

public class ArchivoAudio extends Archivo {

	@Override
	void mostrarContenido() {
		System.out.println("Reproduciendo un archivo de audio");

	}

}

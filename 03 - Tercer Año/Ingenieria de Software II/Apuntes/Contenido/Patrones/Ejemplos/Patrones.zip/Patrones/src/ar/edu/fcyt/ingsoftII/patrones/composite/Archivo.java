package ar.edu.fcyt.ingsoftII.patrones.composite;

public abstract class Archivo {

	protected String nombre;

	abstract void mostrarContenido();

}

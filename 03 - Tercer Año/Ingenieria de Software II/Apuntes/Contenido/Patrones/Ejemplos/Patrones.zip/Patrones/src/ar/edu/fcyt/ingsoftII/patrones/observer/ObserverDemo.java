package ar.edu.fcyt.ingsoftII.patrones.observer;

public class ObserverDemo {

	public static void main(String[] args) {
		Sujeto sujeto = new Sujeto();
		new ObservadorBinario(sujeto);
		new ObservadorOctal(sujeto);
		new ObservadorHexa(sujeto);
		
		
		sujeto.setEstado(4);
	}

}

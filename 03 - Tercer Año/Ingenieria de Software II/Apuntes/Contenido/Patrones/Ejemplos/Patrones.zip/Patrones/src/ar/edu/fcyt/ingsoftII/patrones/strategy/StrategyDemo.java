package ar.edu.fcyt.ingsoftII.patrones.strategy;

public class StrategyDemo {

	public static void main(String[] args) {
		Contexto contexto = new Contexto(new Sumar());

		contexto.ejecutarOperacion(2, 3);

		contexto = new Contexto(new Restar());

		contexto.ejecutarOperacion(2, 3);
	}

}

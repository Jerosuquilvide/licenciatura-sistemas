package ar.edu.fcyt.ingsoftII.patrones.composite;

import java.util.List;

public class Directorio extends Archivo {

	private List<Archivo> contenido;

	@Override
	void mostrarContenido() {
		// TODO Auto-generated method stub

	}

}
